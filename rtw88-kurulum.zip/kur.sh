#!/bin/bash
# =====================================================================
#  rtw88.kext (Feixiao) kurulum - Realtek RTL8821CE Wi-Fi
#  Kullanim: zip'i ac, Terminal'de o klasore gir ve:
#     sudo diskutil mount disk0s1
#     bash kur.sh
#  Yaptiklari: config.plist yedegi, rtw88.kext -> EFI/OC/Kexts,
#  Kernel > Add kaydi, rtw88ctl -> /usr/local/bin
# =====================================================================
set -u
kirmizi() { printf "\033[31m%s\033[0m\n" "$1"; }
yesil()   { printf "\033[32m%s\033[0m\n" "$1"; }
dur()     { kirmizi "HATA: $1"; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
[ -d "$HERE/rtw88.kext" ] || dur "rtw88.kext bu klasorde yok."

OC=""
for c in /Volumes/EFI/EFI/OC /Volumes/EFI\ 1/EFI/OC "$PWD/EFI/OC" "$PWD/OC"; do
  [ -f "$c/config.plist" ] && { OC="$c"; break; }
done
[ -n "$OC" ] || dur "EFI bulunamadi. Once: sudo diskutil mount disk0s1"
CFG="$OC/config.plist"
yesil "Kullanilan: $CFG"

TS="$(date +%Y%m%d_%H%M%S)"
sudo cp "$CFG" "$CFG.yedek_$TS" && cp "$CFG" "$HOME/Desktop/config.plist.yedek_$TS" || dur "Yedek alinamadi."
yesil "Yedek: config.plist.yedek_$TS"

WORK="$(mktemp -d)"; P="$WORK/config.plist"; cp "$CFG" "$P"
plutil -lint "$P" >/dev/null || dur "config.plist bozuk."

# kext kopyala
sudo rm -rf "$OC/Kexts/rtw88.kext"
sudo cp -R "$HERE/rtw88.kext" "$OC/Kexts/" || dur "Kext kopyalanamadi."
echo "  rtw88.kext Kexts klasorune kopyalandi."

# config kaydi
n="$(plutil -extract Kernel.Add raw "$P" 2>/dev/null || echo 0)"; found=""
for ((i=0;i<n;i++)); do
  [ "$(plutil -extract "Kernel.Add.$i.BundlePath" raw "$P" 2>/dev/null)" = "rtw88.kext" ] && found="$i"
done
if [ -n "$found" ]; then
  plutil -replace "Kernel.Add.$found.Enabled" -bool YES "$P"; echo "  Config kaydi zaten vardi, etkinlestirildi."
else
  plutil -insert Kernel.Add -xml "<dict>
    <key>Arch</key><string>x86_64</string>
    <key>BundlePath</key><string>rtw88.kext</string>
    <key>Comment</key><string>Feixiao RTL8821CE Wi-Fi</string>
    <key>Enabled</key><true/>
    <key>ExecutablePath</key><string>Contents/MacOS/rtw88</string>
    <key>MaxKernel</key><string></string>
    <key>MinKernel</key><string></string>
    <key>PlistPath</key><string>Contents/Info.plist</string>
  </dict>" -append "$P" && echo "  Config'e eklendi."
fi
plutil -lint "$P" >/dev/null || dur "Yeni config gecersiz, degisiklik yapilmadi."
sudo cp "$P" "$CFG"

# rtw88ctl
sudo mkdir -p /usr/local/bin
sudo cp "$HERE/rtw88ctl" /usr/local/bin/rtw88ctl && sudo chmod +x /usr/local/bin/rtw88ctl
xattr -d com.apple.quarantine /usr/local/bin/rtw88ctl 2>/dev/null
echo "  rtw88ctl /usr/local/bin'e kuruldu."

rm -rf "$WORK"
yesil "Bitti. Yeniden baslat, sonra Terminal'de:  rtw88ctl"
